/* =====================================================================
   pdf.js — server-side PDF generation via headless Chromium (Puppeteer).

   WHY THIS EXISTS
   ----------------
   The old flow generated PDFs in the user's browser with html2pdf.js,
   which rasterizes the DOM to a JPEG using html2canvas, then drops that
   image into a PDF. html2canvas does its own text layout instead of
   using the browser's real OpenType shaping engine, so complex scripts
   like Devanagari broke in predictable ways:
     - जोडाक्षरे (conjuncts) split into separate, wrong glyphs
     - मात्रा (matras/vowel signs) mispositioned or missing
     - occasional तोफू/boxes if the Google Fonts CDN hadn't finished
       loading before the canvas snapshot was taken
     - blurry, non-searchable output (it's a photo, not text)

   This module instead asks a real headless Chrome to print the exact
   same report page to PDF (page.pdf()). Chromium's native text engine
   (HarfBuzz) does correct Indic-script shaping, the self-hosted Noto
   Sans Devanagari font (see public/fonts/fonts.css) is guaranteed to be
   loaded first, and the resulting PDF has real, crisp, selectable text.

   USAGE
   -----
   const { renderSessionPDF } = require('./pdf');
   const buf = await renderSessionPDF(sessionId, `http://127.0.0.1:${PORT}`);
   // buf is a Buffer containing the finished PDF file.
   ===================================================================== */
'use strict';

const puppeteer = require('puppeteer');

let browserPromise = null;
let launching = false;

/* Reuse a single browser instance across requests (much faster than a
   cold launch every time — Chromium startup is the slow part, ~1-2s).
   If the browser process dies/crashes, the next call transparently
   relaunches it. */
async function getBrowser() {
  if (browserPromise) {
    try {
      const b = await browserPromise;
      if (b && b.isConnected()) return b;
    } catch (e) { /* fall through and relaunch */ }
    browserPromise = null;
  }
  if (!launching) {
    launching = true;
    browserPromise = puppeteer.launch({
      headless: true,
      args: [
        '--no-sandbox',                 // required in most container/CI hosts (Render, Docker)
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',      // avoids /dev/shm OOM crashes on small containers
        '--disable-gpu',
        '--font-render-hinting=none'
      ]
    }).finally(() => { launching = false; });
  }
  return browserPromise;
}

/**
 * Render a session's inspection report to a PDF buffer.
 * @param {string} sessionId
 * @param {string} baseUrl  e.g. `http://127.0.0.1:${PORT}` — the server
 *   renders its OWN /report/:id route internally (loopback request), so
 *   the PDF is guaranteed to be byte-for-byte what a user sees on screen.
 * @returns {Promise<Buffer>}
 */
async function renderSessionPDF(sessionId, baseUrl) {
  const browser = await getBrowser();
  const page = await browser.newPage();
  try {
    await page.setViewport({ width: 900, height: 1400 });
    const url = baseUrl + '/report/' + encodeURIComponent(sessionId) + '?pdf=1';
    const resp = await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 });
    if (!resp || !resp.ok()) {
      throw new Error('Report page failed to load (HTTP ' + (resp ? resp.status() : '?') + ')');
    }
    // Belt-and-braces: explicitly wait for every @font-face to finish
    // loading/parsing before snapshotting, even though font-display:block
    // in fonts.css already blocks first paint on this.
    await page.evaluate(() => document.fonts && document.fonts.ready);

    const pdfBuffer = await page.pdf({
      printBackground: true,
      preferCSSPageSize: true,   // honor the @page { size:A4; margin:8mm } rule in report.js CSS
      timeout: 30000
    });
    return pdfBuffer;
  } finally {
    await page.close().catch(() => {});
  }
}

/* Call on process shutdown (SIGTERM/SIGINT) so Render's redeploy/restart
   cycle doesn't leave an orphaned Chromium process behind. */
async function closeBrowser() {
  if (!browserPromise) return;
  try {
    const b = await browserPromise;
    if (b) await b.close();
  } catch (e) { /* already gone */ }
  browserPromise = null;
}

module.exports = { renderSessionPDF, closeBrowser };
